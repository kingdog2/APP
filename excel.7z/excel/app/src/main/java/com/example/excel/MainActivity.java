package com.example.excel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
///有新增資料就改 還是一次改
public class MainActivity extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);
        /*寫讀權限
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.READ_EXTERNAL_STORAGE},
                PackageManager.PERMISSION_GRANTED);*/
        updateExcel();
    }
    ///創EXCEL(不覆蓋)
    private void createExcelFile(){
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = wb.createSheet("Demo Excel Sheet0");

        ///row
        HSSFRow row = sheet.createRow(0);
        HSSFCell cell = row.createCell(0);
        cell.setCellValue("Person Name");

        cell = row.createCell(1);
        cell.setCellValue("Phone Number");

        cell = row.createCell(2);
        cell.setCellValue("Email  Address");

        ///column width
        sheet.setColumnWidth(0, 20*200);
        sheet.setColumnWidth(1, 30*200);
        sheet.setColumnWidth(2, 30*200);
        for (int i=0;i <3;i++){
            HSSFRow row1 = sheet.createRow(i+1);

            cell = row1.createCell(0);
            cell.setCellValue("name"+i);

            cell = row1.createCell(1);
            cell.setCellValue("Number"+i);

            cell = row1.createCell(2);
            cell.setCellValue("Email"+i);
            /*
            sheet.setColumnWidth(0, 20*200);
            sheet.setColumnWidth(1, 30*200);
            sheet.setColumnWidth(2, 30*200);
            */
        }

        File filePath = new File( Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/Demo1.xls");
        Toast.makeText(this, Environment.getExternalStorageDirectory().getAbsolutePath(), Toast.LENGTH_SHORT).show();
        try {
            ///不存在 建立
            if (!filePath.exists()){
                filePath.createNewFile();
                Toast.makeText(this, "0", Toast.LENGTH_SHORT).show();
                FileOutputStream outputStream = new FileOutputStream(filePath);
                wb.write(outputStream);
                Toast.makeText(getApplicationContext(), "Excel Created in " + filePath, Toast.LENGTH_SHORT).show();
                if (outputStream!=null){
                    Toast.makeText(this, "1", Toast.LENGTH_SHORT).show();
                    outputStream.flush();
                    outputStream.close();
                }
            }
            ///存在不建立
            Toast.makeText(this, "success", Toast.LENGTH_SHORT).show();
        } catch (Exception e){
            Toast.makeText(this, "failed", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
    public static void readExcel(){
        FileInputStream input = null;
        String fileName = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/Demo1.xls";

        try {
            input = new FileInputStream(fileName);

            @SuppressWarnings("resource")
            HSSFWorkbook book = new HSSFWorkbook(input);

            HSSFSheet sheet = book.getSheetAt(0);
            HSSFRow row = sheet.getRow(0);

            HSSFCell cell = null;
            String title = "讀取單元格內容: ";
            for(int i = 0; i< 3; i++) {
                cell = row.getCell(i);
                System.out.println(title + cell.getStringCellValue()+"\n");
                Log.i("success","success");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void updateExcel(){
        FileInputStream input = null;
        String fileName = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/Demo1.xls";
        ///讀
        try {
            input = new FileInputStream(fileName);

            @SuppressWarnings("resource")
            HSSFWorkbook book = new HSSFWorkbook(input);
            if(book.getSheet("Demo Excel Sheet1")==null){
                book.createSheet("Demo Excel Sheet1");
            }///小心!!!有還創會一樣失敗
            HSSFSheet sheet = book.getSheetAt(0);

            /*///在指定sheet創建cell
            HSSFSheet sheet = book.getSheet("Demo Excel Sheet1");
            HSSFRow row2 = sheet.createRow(0);
            HSSFCell cell = row2.createCell(0);
            cell.setCellValue("123");
            sheet.setColumnWidth(0, 30*200);*/

            /*///修改資料某row裡其中一個cell
            HSSFRow row1 = sheet.getRow(2);
            HSSFCell cell = row1.createCell(1);
            cell.setCellValue("name修改");*/

            /*///多一個欄位
            HSSFRow row = sheet.getRow(0);
            HSSFCell cell = row.createCell(3);
            cell.setCellValue("HomeName");
            sheet.setColumnWidth(3, 30*200);*/

            /*///加入資料
            HSSFRow row = sheet.createRow(sheet.getLastRowNum()+1);
            HSSFCell cell = row.createCell(0);
            cell.setCellValue("name"+300);

            cell = row.createCell(1);
            cell.setCellValue("Number"+300);

            cell = row.createCell(2);
            cell.setCellValue("Email"+300);
            */


            ///寫(覆蓋)
            File filePath = new File( Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/Demo1.xls");
            try {
                FileOutputStream outputStream = new FileOutputStream(filePath);
                book.write(outputStream);
                if (outputStream!=null){
                    outputStream.flush();
                    outputStream.close();
                }
                Toast.makeText(this, "success", Toast.LENGTH_SHORT).show();
            } catch (Exception e){
                e.printStackTrace();
                Toast.makeText(this, "failed", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "failed", Toast.LENGTH_SHORT).show();
        }
    }

    /*
    /***將檔案分享出去的視窗***
    Uri path = Uri.fromFile(file);
    Intent fileIntent = new Intent(Intent.ACTION_SEND);
    fileIntent.setType("text/txt");
    fileIntent.putExtra(Intent.EXTRA_SUBJECT, fileName);
    fileIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    fileIntent.putExtra(Intent.EXTRA_STREAM, path);
    startActivity(Intent.createChooser(fileIntent, "輸出檔案"));
    */
}