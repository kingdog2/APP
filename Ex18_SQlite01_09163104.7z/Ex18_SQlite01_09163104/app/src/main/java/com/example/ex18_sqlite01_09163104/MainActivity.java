package com.example.ex18_sqlite01_09163104;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends ListActivity {
    static int count=0;
    private  CommentsDataSource dataSource;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dataSource = new CommentsDataSource(this);
        dataSource.open();

        List<Comment> values = dataSource.getAllComments();
        count = values.size();

        ArrayAdapter<Comment> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, values);
        setListAdapter(adapter);

    }
    protected void onResume(){
        dataSource.open();
        super.onResume();
    }
    protected void onPause(){
        dataSource.open();
        super.onPause();
    }
    public void OnClick(View view){
        ArrayAdapter<Comment> adapter = (ArrayAdapter<Comment>) getListAdapter();
        Comment comment = null;
        switch (view.getId()){
            case R.id.add:
                String[] comments = new String[] {"Cool", "Very nice", "Hate it"};
                int nextInt = new Random().nextInt(3);
                count++;
                comment = dataSource.createComment(comments[nextInt]+"-"+count);
                adapter.add(comment);
                break;
            case R.id.delete:
                if(getListAdapter().getCount() > 0){
                    comment = (Comment) getListAdapter().getItem(0);
                    dataSource.deleteComment(comment);
                    adapter.remove(comment);
                }
                break;
        }
        adapter.notifyDataSetChanged();
    }
}