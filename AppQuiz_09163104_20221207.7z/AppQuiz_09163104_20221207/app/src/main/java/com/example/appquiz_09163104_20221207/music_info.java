package com.example.appquiz_09163104_20221207;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class music_info extends AppCompatActivity implements View.OnClickListener{
    public SQLite DH = new SQLite(this);
    Intent intent;
    TextView title, time_and_endTime, location, locationName, onSales, price, descriptionFilterHtml, masterUnit, webSales, sourceWebPromote , hitRate;
    Button back_button0;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_info);

        title = findViewById(R.id.title);
        time_and_endTime = findViewById(R.id.time_and_endTime);
        location = findViewById(R.id.location);
        locationName = findViewById(R.id.locationName);
        onSales = findViewById(R.id.onSales);
        price = findViewById(R.id.price);
        descriptionFilterHtml = findViewById(R.id.descriptionFilterHtml);
        masterUnit = findViewById(R.id.masterUnit);
        webSales = findViewById(R.id.webSales);
        sourceWebPromote = findViewById(R.id.sourceWebPromote);
        hitRate = findViewById(R.id.hitRate);
        back_button0 = findViewById(R.id.back_button0);
        back_button0.setOnClickListener(this);

        intent = getIntent();
        int seek = intent.getIntExtra("info",0);

        SQLiteDatabase db =DH.getWritableDatabase();

        ////
        Cursor cursor = db.query("music", new String[]{"_id", "_title", "_time", "_location", "_locationName", "_onSales", "_price", "_endTime", "_descriptionFilterHtml", "_masterUnit", "_webSales", "_sourceWebPromote", "_hitRate"},"_id" + "="+ seek,null,null,null,null);
        cursor.moveToFirst();
        title.setText("(活動名稱)" + cursor.getString(1));
        time_and_endTime.setText("單場次演出時間、結束時間" + cursor.getString(2)+cursor.getString(7));
        location.setText("地址" + cursor.getString(3));
        locationName.setText("場地名稱" + cursor.getString(4));
        onSales.setText("是否售票" + cursor.getString(5));
        price.setText("售票說明" + cursor.getString(6));
        descriptionFilterHtml.setText("(簡介說明)" + cursor.getString(8));
        masterUnit.setText("(主辦單位)" + cursor.getString(9));
        webSales.setText("售票網址" + cursor.getString(10));
        sourceWebPromote.setText("推廣網址" + cursor.getString(11));
        hitRate.setText("點閱數:" + Integer.toString(cursor.getInt(12)));


        /*法二
        String query = "SELECT * FROM music";
        SQLiteDatabase db =DH.getReadableDatabase();
        Cursor cursor = null;
        if(db!=null){
            cursor = db.rawQuery(query, null);
        }
        if(cursor.getCount() == 0){
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }else{
            while(cursor.moveToNext()){
                cursor.getInt(0);
                cursor.getString(1);
                cursor.getString(2);
            }
        }
         */
    }

    @Override
    public void onClick(View v) {
        intent = new Intent(this, MainActivity_09163104.class);
        startActivity(intent);
    }
}