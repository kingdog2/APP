package com.example.appquiz_09163104_20221207;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.SQLData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MainActivity_09163104 extends AppCompatActivity {
    public SQLite DH =null;
    SQLiteDatabase db;
    ArrayList<stringData> stringDatas = new ArrayList<stringData>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_09163104);


        getData_JSONObject();

        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        MyListAdapter adapter = new MyListAdapter();

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity_09163104.this));
        recyclerView.setAdapter(adapter);

    }
    private void getData_JSONObject(){
        Response.Listener<JSONArray> response_listener = new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Log.d("jpyuMsg", "response = " + response.toString());
                parserJsonObject(response);
                Log.i("jpyuMsg", "after parserJsonObject");
            }
        };
        Response.ErrorListener response_errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("jpyuMsg", "error : " + error.toString());
            }
        };
        ///https://gis.taiwan.net.tw/XMLReleaseALL_public/scenic_spot_C_f.json
        String url = "https://cloud.culture.tw/frontsite/trans/SearchShowAction.do?method=doFindTypeJ&category=1";
        Log.i("jpyuMsg", url);

        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest(url, response_listener, response_errorListener);
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonObjectRequest);
        Log.i("jpyuMsg", "csist");
    }
    private void parserJsonObject(JSONArray jsonArray){
        ///Log.i("jpyuMsg", "jpyu parser");
        DH = new SQLite(this);
        db =DH.getWritableDatabase();
        try {
            int i=0;
            while (i<=10) {
                JSONObject data = jsonArray.getJSONObject(i);
                JSONObject data2 = data.getJSONArray("showInfo").getJSONObject(0);
                ///Log.i("jpyuMsg", data.toString());

                String title = data.getString("title");
                ///Log.i("jpyuMsg", data.getString("title"));


                String time = data2.getString("time");
                //Log.i("jpyuMsg", data2.getString("time"));
                String location = data2.getString("location");
                //Log.i("jpyuMsg", data2.getString("location"));
                String locationName = data2.getString("locationName");
                //Log.i("jpyuMsg", data2.getString("locationName"));
                String onSales = data2.getString("onSales");
                //Log.i("jpyuMsg", data2.getString("onSales"));
                String price = data2.getString("price");
                ///Log.i("jpyuMsg", data2.getString("price"));
                String endTime = data2.getString("endTime");
                ///Log.i("jpyuMsg", data2.getString("endTime"));


                String descriptionFilterHtml = data.getString("descriptionFilterHtml");
                ///Log.i("jpyuMsg", data.getString("descriptionFilterHtml"));
                String masterUnit = data.getString("masterUnit");
                ///Log.i("jpyuMsg", data.getString("masterUnit"));
                String webSales = data.getString("webSales");
                ///Log.i("jpyuMsg", data.getString("webSales"));
                String sourceWebPromote = data.getString("sourceWebPromote");
                ///Log.i("jpyuMsg", data.getString("sourceWebPromote"));

                int hitRate = data.getInt("hitRate");
                //Log.i("jpyuMsg", data.getInt("hitRate"));

                /*json給資料stringData*/
                stringData stringData = new stringData();
                stringData.setTitle(title);
                stringData.setTime(time);
                stringData.setLocation(location);
                stringDatas.add(stringData);




                add(title, time, location, locationName, onSales, price, endTime, descriptionFilterHtml, masterUnit, webSales, sourceWebPromote, hitRate);
                i++;
            }
        }catch (JSONException e){
            e.printStackTrace();
        }
    }
    private void add(String title, String time, String location, String locationName, String onSales, String price, String endTime, String descriptionFilterHtml, String masterUnit, String webSales, String sourceWebPromote , int hitRate){
        ContentValues values = new ContentValues();
        values.put("_title", title);
        values.put("_time", time);
        values.put("_location", location);
        values.put("_locationName", locationName);
        values.put("_onSales", onSales);
        values.put("_price", price);
        values.put("_endTime", endTime);
        values.put("_descriptionFilterHtml", descriptionFilterHtml);
        values.put("_masterUnit", masterUnit);
        values.put("_webSales", webSales);
        values.put("_sourceWebPromote", sourceWebPromote);
        values.put("_hitRate", hitRate);

        long result = db.insert("music", null, values);
        if(result==-1){
            Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Successfully", Toast.LENGTH_SHORT).show();
        }

        /*
        Cursor cursor = db.query("music", new String[]{"_id", "_title", "_time"},null,null,null,null,null);
        List<Map<String,Object>> items = new ArrayList<Map<String,Object>>();
        cursor.moveToFirst();
        for(int i=0; i<cursor.getCount(); i++){
            Map<String,Object> item = new HashMap<String, Object>();
            item.put("_id", cursor.getString(0));
            item.put("_title", cursor.getString(1));
            item.put("_time", cursor.getString(2));
            items.add(item);
            cursor.moveToNext();
        }*/


    }
    public class MyListAdapter extends RecyclerView.Adapter<MyListAdapter.ViewHolder> {

        @NonNull
        @Override
        public MyListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            View listItem = layoutInflater.inflate(R.layout.list_item,parent, false);
            MyListAdapter.ViewHolder viewHolder = new MyListAdapter.ViewHolder(listItem);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull MyListAdapter.ViewHolder holder, int position) {
            final stringData myListData =  stringDatas.get(position);
            holder.textView0.setText(position+" "+ stringDatas.get(position).getTitle());
            holder.textView1.setText(stringDatas.get(position).getTime());
            holder.textView2.setText(stringDatas.get(position).getLocation());

        }

        @Override
        public int getItemCount() {
            return stringDatas.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder{

            public TextView textView0;
            public TextView textView1;
            public TextView textView2;
            public LinearLayout linearLayout ;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                this.textView0 = (TextView) itemView.findViewById(R.id.textView0);
                this.textView1 = (TextView) itemView.findViewById(R.id.textView1);
                this.textView2 = (TextView) itemView.findViewById(R.id.textView2);
                linearLayout = (LinearLayout) itemView.findViewById(R.id.linearLayout);
                linearLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(MainActivity_09163104.this, music_info.class);
                        int i = Integer.valueOf(((TextView)v.findViewById(R.id.textView0)).getText().toString().split(" ")[0]).intValue();
                        intent.putExtra("info", i);
                        startActivity(intent);
                        ///Toast.makeText(MainActivity_09163104.this, ((TextView)v.findViewById(R.id.textView0)).getText().toString().split(" ")[0], Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
    }

}